from plotter import Plotter


def main():
    plotter = Plotter()
    print("read polygon.csv")

    print("read input.csv")

    print("categorize points")

    print("write output.csv")

    print("plot polygon and points")
    plotter.show()


if __name__ == "__main__":
    main()
